public  class OBJECT1
{
    
    static void sample()
    {
        System.out.println("HELLO MYSTATIC METHOD IS CALLED WITHOUT OBJECT BEING CREATED!!");
    }
    public void mypublicmethod()
    {
        System.out.println("HELLOE MYPUBLIC METHOD IS CALLEDD USING OBJECT CREATION ONLY!!");
    }

}
