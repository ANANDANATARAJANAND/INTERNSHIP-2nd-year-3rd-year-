public class OBJECT2
{   public static void main(String[] args)
    {   OBJECT1.sample();
        OBJECT1 obj=new OBJECT1();
        //mypublicmethod;
        obj.mypublicmethod();
    }
}