public class OB2 {
    public  static void main(String[] args)
    {
        OB1 myobj=new OB1();
        myobj.setName("AJAY");
        System.out.println("Name :" + myobj.getName());


    }
    
}
