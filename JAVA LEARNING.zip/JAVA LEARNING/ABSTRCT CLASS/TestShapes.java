public class TestShapes {
    public static void main(String[] args) {
        OBJECT1 s1 = new Circle();  
        OBJECT1 s2 = new Square();

        s1.draw();  
        s2.draw();  
    }
}
