import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class ChatClient {
    private JFrame frame;
    private JTextArea chatArea;
    private JTextField inputField;
    private PrintWriter out;
    private BufferedReader in;
    private String name;

    public ChatClient(String serverAddress, int port) throws IOException {
        Socket socket = new Socket(serverAddress, port);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        name = JOptionPane.showInputDialog(frame, "Enter your name:");
        if (name == null || name.trim().isEmpty()) {
            name = "Anonymous";
        }
        out.println(name);

        buildGUI();

        // Thread to listen for messages
        new Thread(() -> {
            String msg;
            try {
                while ((msg = in.readLine()) != null) {
                    chatArea.append(msg + "\n");
                }
            } catch (IOException e) {
                chatArea.append("Disconnected from server.\n");
            }
        }).start();
    }

    private void buildGUI() {
        frame = new JFrame("Java Chat - " + name);
        chatArea = new JTextArea(20, 40);
        chatArea.setEditable(false);
        chatArea.append("Welcome, " + name + "!\n"); // Welcome message here
        inputField = new JTextField(30);

        inputField.addActionListener(e -> {
            String msg = inputField.getText();
            if (!msg.isEmpty()) {
                out.println(msg);
                chatArea.append("Me: " + msg + "\n");
                inputField.setText("");
            }
        });

        frame.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        frame.add(inputField, BorderLayout.SOUTH);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) throws IOException {
        new ChatClient("127.0.0.1", 23456);
    }
}