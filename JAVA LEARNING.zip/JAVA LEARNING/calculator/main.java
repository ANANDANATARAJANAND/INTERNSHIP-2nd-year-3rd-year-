package calculator;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean keepRunning = true;

        System.out.println("Simple Calculator");

        while (keepRunning) {
            System.out.print("Enter first number: ");
            double num1 = sc.nextDouble();

            System.out.print("Enter operator (+, -, *, /): ");
            char op = sc.next().charAt(0);

            System.out.print("Enter second number: ");
            double num2 = sc.nextDouble();

            double result = 0;
            boolean valid = true;

            switch (op) {
                case '+':
                    result = app.add(num1, num2);
                    break;
                case '-':
                    result = app.subtract(num1, num2);
                    break;
                case '*':
                    result = app.multiply(num1, num2);
                    break;
                case '/':
                    try {
                        result = app.divide(num1, num2);
                    } catch (ArithmeticException e) {
                        System.out.println("Error: " + e.getMessage());
                        valid = false;
                    }
                    break;
                default:
                    System.out.println("Invalid operator!");
                    valid = false;
            }

            if (valid) {
                System.out.println("Result: " + result);
            }

            System.out.print("Do you want to perform another calculation? (y/n): ");
            char choice = sc.next().charAt(0);
            if (choice != 'y' && choice != 'Y') {
                keepRunning = false;
            }
        }
        sc.close();
    }
}
