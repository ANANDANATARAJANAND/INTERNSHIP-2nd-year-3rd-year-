public class Grade {
    private String courseName;
    private double gradeValue;

    public Grade(String courseName, double gradeValue) {
        this.courseName = courseName;
        this.gradeValue = gradeValue;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getGradeValue() {
        return gradeValue;
    }

    public void setGradeValue(double gradeValue) {
        this.gradeValue = gradeValue;
    }

    public static double calculateAverage(Grade[] grades) {
        if (grades == null || grades.length == 0) {
            return 0;
        }
        double total = 0;
        for (Grade grade : grades) {
            total += grade.getGradeValue();
        }
        return total / grades.length;
    }
}