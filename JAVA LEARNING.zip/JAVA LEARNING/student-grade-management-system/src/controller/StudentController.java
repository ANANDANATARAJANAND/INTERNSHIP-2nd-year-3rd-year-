import model.Student;
import model.Grade;
import java.util.ArrayList;
import java.util.List;

public class StudentController {
    private List<Student> students;

    public StudentController() {
        this.students = new ArrayList<>();
    }

    public void addStudent(String name, String id) {
        Student student = new Student(name, id);
        students.add(student);
    }

    public void updateStudent(String id, String newName) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                student.setName(newName);
                break;
            }
        }
    }

    public void deleteStudent(String id) {
        students.removeIf(student -> student.getId().equals(id));
    }

    public void assignGrade(String studentId, String courseName, double gradeValue) {
        for (Student student : students) {
            if (student.getId().equals(studentId)) {
                Grade grade = new Grade(courseName, gradeValue);
                student.addGrade(grade);
                break;
            }
        }
    }

    public double calculateAverageGrade(String studentId) {
        for (Student student : students) {
            if (student.getId().equals(studentId)) {
                return student.calculateAverageGrade();
            }
        }
        return 0.0;
    }

    public List<Student> getStudents() {
        return students;
    }
}