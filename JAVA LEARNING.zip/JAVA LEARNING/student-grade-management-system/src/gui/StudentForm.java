import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentForm extends JFrame {
    private JTextField nameField;
    private JTextField idField;
    private JTextField coursesField;
    private JButton submitButton;
    
    public StudentForm() {
        setTitle("Student Form");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 2));
        
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        
        JLabel idLabel = new JLabel("Student ID:");
        idField = new JTextField();
        
        JLabel coursesLabel = new JLabel("Courses:");
        coursesField = new JTextField();
        
        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle form submission logic here
                String name = nameField.getText();
                String id = idField.getText();
                String courses = coursesField.getText();
                // Add logic to save the student record
                JOptionPane.showMessageDialog(null, "Student record submitted:\nName: " + name + "\nID: " + id + "\nCourses: " + courses);
            }
        });
        
        add(nameLabel);
        add(nameField);
        add(idLabel);
        add(idField);
        add(coursesLabel);
        add(coursesField);
        add(new JLabel()); // Empty cell
        add(submitButton);
    }
}