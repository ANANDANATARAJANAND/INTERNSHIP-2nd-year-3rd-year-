# Student Grade Management System

This project is a Student Grade Management System built using Java and Swing. It provides a graphical user interface (GUI) for managing student records and their corresponding grades.

## Features

- Add, update, and delete student records.
- Manage student grades for various courses.
- Calculate average grades for students.
- User-friendly GUI for easy navigation and data entry.

## Project Structure

```
student-grade-management-system
├── src
│   ├── Main.java
│   ├── gui
│   │   ├── MainFrame.java
│   │   └── StudentForm.java
│   ├── model
│   │   ├── Student.java
│   │   └── Grade.java
│   └── controller
│       └── StudentController.java
```

## Setup Instructions

1. Ensure you have Java Development Kit (JDK) installed on your machine.
2. Clone the repository or download the project files.
3. Open the project in your preferred IDE.
4. Navigate to the `src` directory and run `Main.java` to start the application.

## Usage Guidelines

- Upon launching the application, you will see the main window where you can manage student records.
- Use the Student Form to add new students or update existing records.
- Grades can be assigned to students through the interface, and average grades can be calculated automatically.

## License

This project is open-source and available for modification and distribution.