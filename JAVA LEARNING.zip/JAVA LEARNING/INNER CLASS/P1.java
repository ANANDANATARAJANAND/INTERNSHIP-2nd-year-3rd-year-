class P1
{    int x=5;
    class P4
    {
         int y=6;

    }
}