public class P2 {
    public static void main(String[] args) {
        P1 obj1 = new P1();
        P1.P4 obj2 = P1.new P4();

        System.out.println(obj1.x + obj2.y);
    }
}