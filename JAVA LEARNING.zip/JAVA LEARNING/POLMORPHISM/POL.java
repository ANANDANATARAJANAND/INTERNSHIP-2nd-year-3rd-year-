public  class POL
{
    public void POL1()
    {
         System.out.println("WELCOME TO SUPER CLASS POL1");
    }
}
class s extends POL
{
    public void POL1()
    {
         System.out.println("WELCOME TO SUB CLASS p");
    }   
}
class p extends POL
{
    public void POL1()
    {
        System.out.println("WELOCME TO SUB CLASS 2 p");
    }
}