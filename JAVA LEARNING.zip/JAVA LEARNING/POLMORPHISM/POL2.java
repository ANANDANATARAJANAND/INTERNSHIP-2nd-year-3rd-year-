public class POL2
{
    public static void main( String [] args)
    {
        POL obj=new POL();
        s obj2=new s();
        p obj3=new p();
        obj.POL1();
        obj2.POL1();
        obj3.POL1();
    }

}