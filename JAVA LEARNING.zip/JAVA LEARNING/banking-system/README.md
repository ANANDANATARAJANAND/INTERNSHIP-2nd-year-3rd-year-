# Banking System

This is a simple banking system implemented in Java using Swing for the graphical user interface. The application simulates basic banking operations such as account creation, deposits, withdrawals, and transfers.

## Features

- Create new bank accounts
- Deposit money into accounts
- Withdraw money from accounts
- Transfer money between accounts
- Data persistence through file storage

## Project Structure

```
banking-system
├── src
│   ├── gui
│   │   ├── MainFrame.java
│   │   ├── AccountCreationPanel.java
│   │   ├── DepositPanel.java
│   │   ├── WithdrawPanel.java
│   │   └── TransferPanel.java
│   ├── model
│   │   ├── Account.java
│   │   └── Transaction.java
│   ├── service
│   │   └── BankingService.java
│   ├── storage
│   │   └── FileStorage.java
│   └── Main.java
└── README.md
```

## Setup Instructions

1. Ensure you have Java Development Kit (JDK) installed on your machine.
2. Clone the repository or download the project files.
3. Open the project in your preferred IDE.
4. Compile the source files.
5. Run the `Main.java` file to start the application.

## Usage Guidelines

- To create a new account, navigate to the account creation panel and fill in the required details.
- Use the deposit panel to add funds to an existing account by entering the account number and the deposit amount.
- Withdraw funds using the withdrawal panel by providing the account number and the amount to withdraw.
- Transfer funds between accounts using the transfer panel by specifying the source account, destination account, and the transfer amount.

## License

This project is licensed under the MIT License.