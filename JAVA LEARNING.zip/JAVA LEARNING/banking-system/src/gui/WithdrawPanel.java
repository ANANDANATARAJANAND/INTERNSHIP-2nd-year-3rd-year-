package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WithdrawPanel extends JPanel {
    private JTextField accountNumberField;
    private JTextField withdrawalAmountField;
    private JButton withdrawButton;
    private JLabel messageLabel;

    public WithdrawPanel() {
        setLayout(new GridLayout(4, 2));

        JLabel accountNumberLabel = new JLabel("Account Number:");
        accountNumberField = new JTextField();
        JLabel withdrawalAmountLabel = new JLabel("Withdrawal Amount:");
        withdrawalAmountField = new JTextField();
        withdrawButton = new JButton("Withdraw");
        messageLabel = new JLabel("");

        add(accountNumberLabel);
        add(accountNumberField);
        add(withdrawalAmountLabel);
        add(withdrawalAmountField);
        add(withdrawButton);
        add(messageLabel);

        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleWithdraw();
            }
        });
    }

    private void handleWithdraw() {
        String accountNumber = accountNumberField.getText();
        String amountText = withdrawalAmountField.getText();

        if (accountNumber.isEmpty() || amountText.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountText);
            // Call the BankingService to perform the withdrawal operation
            // BankingService.withdraw(accountNumber, amount);
            messageLabel.setText("Withdrawal successful.");
        } catch (NumberFormatException e) {
            messageLabel.setText("Invalid amount.");
        }
    }
}