package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class DepositPanel extends JPanel {
    private JTextField accountNumberField;
    private JTextField depositAmountField;
    private JButton depositButton;
    private JLabel messageLabel;

    public DepositPanel() {
        setLayout(new GridLayout(4, 2));

        JLabel accountNumberLabel = new JLabel("Account HOLDER NAME:");
        accountNumberField = new JTextField();
        JLabel depositAmountLabel = new JLabel("Deposit Amount:");
        depositAmountField = new JTextField();
        depositButton = new JButton("Deposit");
        messageLabel = new JLabel("");

        add(accountNumberLabel);
        add(accountNumberField);
        add(depositAmountLabel);
        add(depositAmountField);
        add(depositButton);
        add(messageLabel);

        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleDeposit();
            }
        });
    }

    private void handleDeposit() {
        String accountNumber = accountNumberField.getText();
        String depositAmount = depositAmountField.getText();

        // Here you would typically call the BankingService to perform the deposit
        // For now, we will just display a success message
        messageLabel.setText("Deposit of " + depositAmount + " to account " + accountNumber + " successful.");
    }
}