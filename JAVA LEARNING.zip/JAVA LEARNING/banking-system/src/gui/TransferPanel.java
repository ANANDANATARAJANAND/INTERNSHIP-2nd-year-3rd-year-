package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class TransferPanel extends JPanel {
    private JTextField sourceUsernameField;
    private JTextField destinationUsernameField;
    private JTextField amountField;
    private JButton transferButton;
    private JLabel messageLabel;

    public TransferPanel() {
        setLayout(new GridLayout(5, 2));

        JLabel sourceUsernameLabel = new JLabel("Source ACCOUNT NO:");
        sourceUsernameField = new JTextField();
        JLabel destinationUsernameLabel = new JLabel("Destination ACCOUNT NO:");
        destinationUsernameField = new JTextField();
        JLabel amountLabel = new JLabel("Amount:");
        amountField = new JTextField();
        transferButton = new JButton("Transfer");
        messageLabel = new JLabel("");

        add(sourceUsernameLabel);
        add(sourceUsernameField);
        add(destinationUsernameLabel);
        add(destinationUsernameField);
        add(amountLabel);
        add(amountField);
        add(transferButton);
        add(messageLabel);

        transferButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performTransfer();
            }
        });
    }

    private void performTransfer() {
        String sourceUsername = sourceUsernameField.getText();
        String destinationUsername = destinationUsernameField.getText();
        String amountText = amountField.getText();

        if (sourceUsername.isEmpty() || destinationUsername.isEmpty() || amountText.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountText);
            // Here you would call the BankingService to perform the transfer
            // BankingService.transfer(sourceUsername, destinationUsername, amount);
            messageLabel.setText("Transfer successful!");
        } catch (NumberFormatException e) {
            messageLabel.setText("Invalid amount.");
        }
    }
}