package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccountCreationPanel extends JPanel {
    private JTextField accountNumberField;
    private JTextField usernameField;
    private JTextField initialBalanceField;
    private JButton createButton;
    private JLabel messageLabel;

    public AccountCreationPanel() {
        setLayout(new GridLayout(5, 2));

        JLabel accountNumberLabel = new JLabel("Account Number:");
        accountNumberField = new JTextField();
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        JLabel initialBalanceLabel = new JLabel("Initial Balance:");
        initialBalanceField = new JTextField();
        createButton = new JButton("Create Account");
        messageLabel = new JLabel("");

        add(accountNumberLabel);
        add(accountNumberField);
        add(usernameLabel);
        add(usernameField);
        add(initialBalanceLabel);
        add(initialBalanceField);
        add(createButton);
        add(messageLabel);

        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performAccountCreation();
            }
        });
    }

    private void performAccountCreation() {
        String accountNumber = accountNumberField.getText();
        String username = usernameField.getText();
        String initialBalanceText = initialBalanceField.getText();

        if (accountNumber.isEmpty() || username.isEmpty() || initialBalanceText.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        try {
            double initialBalance = Double.parseDouble(initialBalanceText);
            // Here you would call your service to create the account
            // BankingService.createAccount(accountNumber, username, initialBalance);
            messageLabel.setText("Account created successfully!");
        } catch (NumberFormatException e) {
            messageLabel.setText("Invalid balance.");
        }
    }
}