package service;

import model.Account;
import model.Transaction;
import storage.FileStorage;

import java.util.ArrayList;
import java.util.List;

public class BankingService {
    private List<Account> accounts;
    private FileStorage fileStorage;

    public BankingService() {
        this.fileStorage = new FileStorage();
        this.accounts = fileStorage.loadAccounts();
    }

    public void createAccount(String accountHolderName, String accountNumber) {
        Account newAccount = new Account(accountHolderName, accountNumber);
        accounts.add(newAccount);
        fileStorage.saveAccounts(accounts);
    }

    public void deposit(String accountNumber, double amount) {
        Account account = findAccount(accountNumber);
        if (account != null) {
            account.deposit(amount);
            fileStorage.saveAccounts(accounts);
        }
    }

    public void withdraw(String accountNumber, double amount) {
        Account account = findAccount(accountNumber);
        if (account != null) {
            account.withdraw(amount);
            fileStorage.saveAccounts(accounts);
        }
    }

    public void transfer(String sourceAccountNumber, String destinationAccountNumber, double amount) {
        Account sourceAccount = findAccount(sourceAccountNumber);
        Account destinationAccount = findAccount(destinationAccountNumber);
        if (sourceAccount != null && destinationAccount != null) {
            sourceAccount.withdraw(amount);
            destinationAccount.deposit(amount);
            fileStorage.saveAccounts(accounts);
        }
    }

    private Account findAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        return null;
    }

    public List<Account> getAccounts() {
        return accounts;
    }
}