import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CurrencyConverter {
    private static final Map<String, Double> rates = new HashMap<>();

    static {
        rates.put("USD_INR", 83.0); // Example rate
        rates.put("INR_USD", 0.012);
        // Add more rates as needed
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Currency Converter");
        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();

        System.out.print("From currency (USD/INR): ");
        String from = scanner.next().toUpperCase();

        System.out.print("To currency (USD/INR): ");
        String to = scanner.next().toUpperCase();

        String key = from + "_" + to;
        if (rates.containsKey(key)) {
            double rate = rates.get(key);
            double result = amount * rate;
            System.out.printf("%.2f %s = %.2f %s%n", amount, from, result, to);
        } else {
            System.out.println("Conversion rate not available.");
        }

        scanner.close();
    }
}